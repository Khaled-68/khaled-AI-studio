
import React from "react";
import "./App.css";

function App() {
  return (
    <div className="App">
      <h1>Khaled AI Studio</h1>
      <p>Welcome to the Vercel-ready version!</p>
      <div className="images">
        <img src="/img1.jpg" alt="img1"/>
        <img src="/img2.jpg" alt="img2"/>
        <img src="/img3.jpg" alt="img3"/>
        <img src="/img4.jpg" alt="img4"/>
      </div>
    </div>
  );
}

export default App;
